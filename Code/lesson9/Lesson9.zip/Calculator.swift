//
//  Calculator.swift
//  demo_objc_in_swift
//
//  Created by bryant on 24/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

import UIKit

class Calculator: NSObject {
    
    private var M1:Double?
    private var M2:Double?
    private var M3:Double?
    private var result:Double = 0.0
    private var operand:Double = 0.0
    private var operator_: String = ""
    
    func clear(){
        operator_ = "";
        operand = 0.0;
        result = 0.0;
    }
    
    func setOperator(op:String) {
        operator_ = op
    }
    
    func setOperand(text:String) {
        operand = Double(text)!
    }
    
    func calculate(){
        if operator_ == "+" {
            result = result + operand
        }else if operator_ == "-"{
            result = result - operand
        }else if operator_ == "/"{
            result = result / operand
        }else if operator_ == "x"{
            result = result * operand
        }else if operator_ == ""{
            result = operand
        }
        operand = 0.0
    }
    
    func getResult() -> String {
        return String(result)
    }
    
}
