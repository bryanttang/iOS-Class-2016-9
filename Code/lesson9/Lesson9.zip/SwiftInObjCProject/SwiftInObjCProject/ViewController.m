//
//  ViewController.m
//  SwiftInObjCProject
//
//  Created by bryant on 24/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import "ViewController.h"
#import "SwiftInObjCProject-Swift.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    Calculator *cal = [Calculator new];
    [cal setOperandWithText:@"1"];
    [cal calculate];
    [cal setOperatorWithOp:@"+"];
    [cal setOperandWithText:@"2"];
    [cal calculate];
    NSLog(@"=============== Result:  %@",[cal getResult]);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
