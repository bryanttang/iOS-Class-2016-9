//
//  ViewController.swift
//  ObjCInSwift
//
//  Created by bryant on 24/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let cal:Calculator = Calculator()
        
        cal.clear()
        cal.setOperand("1")
        cal.calculate()
        cal.setOperator("+")
        cal.setOperand("2")
        cal.calculate()
        print("=============== Result:  "+cal.getResult())
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

