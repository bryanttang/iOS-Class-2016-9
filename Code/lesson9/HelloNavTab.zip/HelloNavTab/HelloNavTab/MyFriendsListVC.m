//
//  MyFriendsListVC.m
//  HelloNavTab
//
//  Created by bryant on 24/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import "MyFriendsListVC.h"
#import "DetailViewController.h"


@interface MyFriendsListVC ()

@end

@implementation MyFriendsListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    myFriends = @[@{@"name":@"Bryant" ,
                    @"aboutme":@"I am a boy"},
                  @{@"name":@"Jessie" ,
                    @"aboutme":@"I am a girl"}
                  ];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return myFriends.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"mycell" forIndexPath:indexPath];
    
    cell.textLabel.text = [[myFriends objectAtIndex:indexPath.row] objectForKey:@"name"];

    
    
    return cell;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 
    if ([segue.identifier isEqualToString:@"toDetail"]) {
        
        DetailViewController *detailVC = (DetailViewController*)segue.destinationViewController;
        
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        NSDictionary *person = [myFriends objectAtIndex:indexPath.row];
        
        detailVC.information = person;
        
    }
    
    
}

@end
