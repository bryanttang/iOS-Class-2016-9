//
//  ViewController.h
//  HelloPickerView
//
//  Created by bryant on 13/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource>{

    NSArray *CDs;
    NSArray *Covers;
}

@property (strong, nonatomic) IBOutlet UILabel *CDName;
@property (strong, nonatomic) IBOutlet UIPickerView *CDList;

@end

