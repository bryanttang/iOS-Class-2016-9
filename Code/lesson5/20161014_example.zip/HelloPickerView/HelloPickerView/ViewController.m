//
//  ViewController.m
//  HelloPickerView
//
//  Created by bryant on 13/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
//    NSArray *CDs = @[@"Bruno Mars",
//                     @"Love Forever" ,
//                     @"Stop"
//                     ];
//    NSLog(@"===================%@", [CDs objectAtIndex:0]);
//    CDs.count
//    NSLog(@"================= %d",  [CDs containsObject:@"Stop"]);
    
    
    NSDictionary *cd1 = @{@"cdname": @"Bruno Mars",
                          @"cover": @"1",
                          @"numberOfSong":@"12"};
    
    NSDictionary *cd2 = @{@"cdname": @"Love Forever",
                          @"cover": @"2",
                          @"numberOfSong":@"12"};
    
    NSDictionary *cd3 = @{@"cdname": @"Stop",
                          @"cover": @"3",
                          @"numberOfSong":@"12"};
    
    CDs = [[NSArray alloc] initWithObjects:
                    cd1,
                    cd2,
                    cd3,
                    nil];
    
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return CDs.count;

}

- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component{
    
    return [CDs objectAtIndex:row];
    
}

- (void)pickerView:(UIPickerView *)pickerView
      didSelectRow:(NSInteger)row
       inComponent:(NSInteger)component{

    self.CDName.text = [CDs objectAtIndex:row];
    
//    NSLog(@"%@", );
}


- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 80;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    //Make Custom View
    UIView *customeView;
    customeView = [[UIView alloc] initWithFrame:view.frame];
    
//    NSDictionary *cd = [CDs objectAtIndex:row];
    
    NSString *cdName = [[CDs objectAtIndex:row] objectForKey:@"cdname"];
    NSString *coverImageName = [[CDs objectAtIndex:row] objectForKey:@"cover"];
    
    //Cover Image
    UIImageView *coverImg = [[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 80, 80)];
    coverImg.image = [UIImage imageNamed:coverImageName];
    [customeView addSubview:coverImg];
    
    //CDName
    UILabel *CDName = [[UILabel alloc] initWithFrame:CGRectMake(100, 0, 100, 80)];
    CDName.text = cdName;
    [customeView addSubview:CDName];
    
    
    //Reture Custom View
    return customeView;
    
}










- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
