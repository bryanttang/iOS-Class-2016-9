//
//  ViewController.h
//  sqlite_demo
//
//  Created by bryant tang on 6/2/14.
//  Copyright (c) 2014 bryant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface ViewController : UIViewController<UITextFieldDelegate>
@property (strong)    IBOutlet UITextField *name;
@property (strong)    IBOutlet UITextField *address;
@property (strong)    IBOutlet UITextField *phone;
@property (strong)  IBOutlet UILabel *status;

- (IBAction)clickSave:(id)sender;
- (IBAction)clickFind:(id)sender;

@property (strong, nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *contactDB;

@end
