//
//  MyCell.h
//  HelloTableViewController
//
//  Created by bryant on 20/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *headimg;
@property (strong, nonatomic) IBOutlet UILabel *name;
@property (strong, nonatomic) IBOutlet UILabel *detail;

@end
