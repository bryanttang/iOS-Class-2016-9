//
//  DetailViewController.h
//  HelloTableViewController
//
//  Created by bryant on 20/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property NSString *inputImage;
@property NSString *inputName;

@property (strong, nonatomic) IBOutlet UIImageView *detailimage;
@property (strong, nonatomic) IBOutlet UILabel *albumName;

@end
