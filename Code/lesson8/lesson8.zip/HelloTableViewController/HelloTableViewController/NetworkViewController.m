//
//  NetworkViewController.m
//  HelloTableViewController
//
//  Created by bryant on 20/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import "NetworkViewController.h"

@interface NetworkViewController ()

@end

@implementation NetworkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSURL *url = [NSURL URLWithString:@"http://store.storeimages.cdn-apple.com/8748/as-images.apple.com/is/image/AppleInc/aos/published/images/w/at/watch/select/watch-select-hermes-header-hero-201609?wid=496&hei=413&fmt=png-alpha&qlt=95&.v=1472520500380"];
    
    NSData *image_data = [NSData dataWithContentsOfURL:url];
    
    _networkImage.image = [UIImage imageWithData:image_data];
    
    
    NSURL *url2 = [NSURL URLWithString:@"https://api.spotify.com/v1/albums?ids=1A2GTWGtFfWp7KSQTwWOyo,2noRn2Aes5aoNVsU6iWThc"];
    
    NSData *json_data = [NSData dataWithContentsOfURL:url2];
    
//    NSString *json_str = [NSString stringWithContentsOfURL:url2 encoding:NSUTF8StringEncoding error:nil];
    
    NSJSONSerialization *json = [NSJSONSerialization JSONObjectWithData:json_data
                                                                options:NSJSONReadingAllowFragments error:nil];
    
    NSDictionary *albums = (NSDictionary*)json;
    
    NSLog(@"%@", albums);
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
