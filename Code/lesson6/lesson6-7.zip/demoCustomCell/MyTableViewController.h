//
//  MyTableViewController.h
//  demoCustomCell
//
//  Created by bryant tang on 4/12/15.
//  Copyright (c) 2015 CPTTM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewController : UITableViewController
{
    
    NSMutableArray *email;
    
}
@end
