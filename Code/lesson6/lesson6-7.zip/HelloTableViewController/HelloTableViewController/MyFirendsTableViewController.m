//
//  MyFirendsTableViewController.m
//  HelloTableViewController
//
//  Created by bryant on 17/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import "MyFirendsTableViewController.h"
#import "MyCell.h"

@interface MyFirendsTableViewController ()

@end

@implementation MyFirendsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    NSDictionary *cd1 = @{@"CDName":@"My Song 1",
                          @"CDImgName":@"1"};
    
    NSDictionary *cd2 = @{@"CDName":@"My Song 2",
                          @"CDImgName":@"2"};
    
    NSDictionary *cd3 = @{@"CDName":@"My Song 3",
                          @"CDImgName":@"3"};
    
    
    
    _CDs2 = [[NSArray alloc] initWithObjects:cd1,
             cd2,
             cd3, nil];
    
    self.tableView.contentInset = UIEdgeInsetsMake(30, 0, 0, 0);
    
    
}

-(BOOL)prefersStatusBarHidden {
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _CDs2.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    MyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"mycell" forIndexPath:indexPath];
    
    NSString *imgName = [[_CDs2 objectAtIndex:indexPath.row] objectForKey:@"CDImgName"];
    
    cell.headimage.image = [UIImage imageNamed:imgName];
    
    cell.cdName.text = [[_CDs2 objectAtIndex:indexPath.row] objectForKey:@"CDName"];
    
    
//    indexPath.section
//    indexPath.row

    
//    cell.textLabel.text = [[_CDs2 objectAtIndex:indexPath.row] objectForKey:@"CDName"];
//    
//    cell.detailTextLabel.text = [[_CDs2 objectAtIndex:indexPath.row] objectForKey:@"CDImgName"];
    
    
    // Configure the cell...
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
