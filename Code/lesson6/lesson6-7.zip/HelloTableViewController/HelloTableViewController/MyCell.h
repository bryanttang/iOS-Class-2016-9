//
//  MyCell.h
//  HelloTableViewController
//
//  Created by bryant on 17/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *headimage;
@property (strong, nonatomic) IBOutlet UILabel *cdName;
@property (strong, nonatomic) IBOutlet UILabel *cdDetail;

@end
