//
//  ViewController.m
//  HelloPickerView
//
//  Created by bryant on 17/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
//    NSArray *CDs = @[@"My Song 1",
//                     @"My Song 2",
//                     @"My Song 3",
//                     @"My Song 4"];
    
    NSArray *CDs = [[NSArray alloc] initWithObjects:@"My Song 1",
                                                    @"My Song 2",
                                                    @"My Song 3",
                                                    @"My Song 4", nil];
    
    
//    NSLog(@"%@", [CDs objectAtIndex:1]);
    
    NSMutableArray *CDs_m = [NSMutableArray arrayWithArray:CDs];
    
    [CDs_m objectAtIndex:0];  //Get object
    
    [CDs_m addObject:@"My Song 5"];  //Add object
    
    NSLog(@"%@", [CDs_m objectAtIndex:4]);  //Read object at position 5
    
    [CDs_m removeObject:@"My Song 3"]; //
    [CDs_m removeObjectAtIndex:2];
    [CDs_m removeAllObjects];
    
    
    
    NSDictionary *cd1 = @{@"CDName":@"My Song 1",
                          @"CDImgName":@"1"};
    
    NSDictionary *cd2 = @{@"CDName":@"My Song 2",
                          @"CDImgName":@"2"};
    
    NSDictionary *cd3 = @{@"CDName":@"My Song 3",
                          @"CDImgName":@"3"};
    
    
    
    _CDs2 = [[NSArray alloc] initWithObjects:cd1,
                                            cd2,
                                            cd3, nil];
}

//Function 1
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
//Function 2
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return self.CDs2.count;
}
//Function 3
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSDictionary *temp = [self.CDs2 objectAtIndex:row];
    
    return [temp objectForKey:@"CDName"];
}












- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
