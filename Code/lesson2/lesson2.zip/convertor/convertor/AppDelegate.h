//
//  AppDelegate.h
//  convertor
//
//  Created by bryant tang on 4/10/14.
//  Copyright (c) 2014 bryant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
