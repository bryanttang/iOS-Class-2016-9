//
//  aViewController.h
//  SpaceBattle
//
//  Created by bryant on 6/10/15.
//  Copyright © 2015 cpttm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface aViewController : UIViewController

@end
