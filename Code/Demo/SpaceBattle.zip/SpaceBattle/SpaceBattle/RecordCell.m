//
//  RecordCell.m
//  SpaceBattle
//
//  Created by bryant on 21/9/15.
//  Copyright © 2015 cpttm. All rights reserved.
//

#import "RecordCell.h"

@implementation RecordCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
