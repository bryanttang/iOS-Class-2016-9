//
//  RecordTableViewController.h
//  SpaceBattle
//
//  Created by bryant on 21/9/15.
//  Copyright © 2015 cpttm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordTableViewController : UITableViewController
{
    NSMutableArray *records;
}
@property NSDictionary *bundle;
@end
