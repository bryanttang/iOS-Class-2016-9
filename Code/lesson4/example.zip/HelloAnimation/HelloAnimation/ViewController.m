//
//  ViewController.m
//  HelloAnimation
//
//  Created by bryant on 6/10/2016.
//  Copyright © 2016 cpttm. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    textView = [[UITextView alloc] initWithFrame:CGRectMake(20, 250, self.view.frame.size.width -40, 250)];
    
    textView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    textView.text = @"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of de Finibus Bonorum et Malorum (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, Lorem ipsum dolor sit amet.., comes from a line in section 1.10.32.The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from de Finibus Bonorum et Malorum by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham. \" ";
    
    [self.view addSubview:textView];
    
    textView.delegate = self;
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(respondsToTap:)];
    
    [self.view addGestureRecognizer:tap];
    
    
    
}


- (void)respondsToTap:(UITapGestureRecognizer*) tap{
    
    [textView resignFirstResponder];
    
    
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         
                         textView.transform = CGAffineTransformIdentity;
                         
                     } completion:^(BOOL finished) {
                         
                     }];
}



- (BOOL)textViewShouldBeginEditing:(UITextView *)textView_{
    
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         
                         textView_.transform = CGAffineTransformMakeTranslation(0, -200);
                         
                     } completion:^(BOOL finished) {
                         
                     }];
    
    return YES;

}




- (void)viewDidAppear:(BOOL)animated{

//    UIView *square = [[UIView alloc] initWithFrame:CGRectMake(20, 50, 150, 50)];
//    square.backgroundColor = [UIColor redColor];
//    [self.view addSubview:square];
//    
//    square.layer.cornerRadius = 25;
//    
//    [UIView animateWithDuration:3
//                          delay:1
//                        options:UIViewAnimationOptionCurveEaseInOut
//                     animations:^{
//                         
//                          square.frame = CGRectMake(220, 50, 50, 50);
//                         
//                     } completion:^(BOOL finished) {
//                         
//                         [UIView animateWithDuration:0.5
//                                          animations:^{
//                                              square.frame = CGRectMake(220, 350, 50, 50);
//                                          }];
//                         
//                     }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
