//
//  ViewController.h
//  PanningView
//
//  Created by bryant tang on 3/17/15.
//  Copyright (c) 2015 CPTTM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong) IBOutlet UIView *panningView;
@property (strong, nonatomic) IBOutlet UILabel *context;


@end

