//
//  ViewController.h
//  animationDemo
//
//  Created by bryant on 9/7/15.
//  Copyright (c) 2015 cpttm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

{
    NSMutableArray *calender_db;
    int date_temp;
    UIView *a;
    UIView *b;
}
@end

